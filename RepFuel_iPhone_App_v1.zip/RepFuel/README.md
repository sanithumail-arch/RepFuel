# RepFuel — Personal Workout & Nutrition Tracker

A small, private, offline-ready iPhone web app. It has no external dependencies, no analytics, no accounts and no backend. All workouts, food records, custom foods, routines, weight logs and targets are saved in **IndexedDB on the device**.

## Features

- **Workout logging:** set-by-set weight (kg), reps, completion checkboxes, saved routines, custom exercises, previous workout numbers and maximum-weight personal records.
- **Food diary:** daily calories and macronutrients, remaining calorie progress ring, offline searchable starter food catalog, custom foods saved with nutrition per 100 g, manual meal entries and portions.
- **Progress:** body weight weigh-ins and trend chart, strength PRs, workout history.
- **Privacy:** all records stay on the device. JSON backup export/import. No cloud sync or tracking.

## Install on iPhone (recommended: GitHub Pages)

You need an HTTPS address to use the app as an installable, offline-capable PWA on an iPhone. You do **not** need a paid Apple Developer account.

1. Download and unzip the RepFuel package.
2. Create a **public** repository in GitHub (for example, `repfuel`). The public repository contains only the app code, **not** your workout/food logs.
3. Upload **all files and the icons folder**, preserving their directory structure, to the repository root.
4. In the repository, visit **Settings → Pages**. Under **Build and deployment**, choose **Deploy from a branch**; select the `main` branch and `/ (root)`. Save.
5. Open the HTTPS Pages link GitHub provides in **Safari on your iPhone**, not inside another app's browser.
6. From Safari's **Share** menu choose **Add to Home Screen** (or **Open as Web App** depending on your iOS version), and tap **Add**.
7. Open RepFuel from the new Home Screen icon. Open the app online once so its files are cached, then it works offline.
8. Open settings (gear icon) and **set your personal calorie/macronutrient goals**. The default values are examples only.
9. Use **Settings → Export JSON backup** regularly. Save the downloaded backup into Files/iCloud Drive or another place you trust. Import replaces existing app data.

Hosting the static app source does not upload or synchronize personal logs. If you open RepFuel on another device, it will have **separate, empty local data** until you import a backup. Clearing Safari site data, uninstalling the web app, or some device storage conditions can cause local data loss, so backups matter.

## Run locally on your Mac or Windows computer

With Python installed, open Terminal or PowerShell in the unzipped `repfuel-pwa` folder:

```sh
python3 -m http.server 8080
```

On Windows, use `py -m http.server 8080` if `python3` is not recognized.

Open `http://localhost:8080` in a desktop browser to test. Opening the HTML file directly with `file://` is not recommended, because service workers require HTTPS or localhost.

## Updating the app

Upload your updated `index.html`, `styles.css`, `app.js`, and other files to the same hosting path. For an update to offline-cached app files, **change the CACHE version in `sw.js`** so installed versions download the newest files. Export your data first.

## Nutrition values

Starter foods provide **rough reference estimates per 100 g**. Nutrition varies by preparation, brand and serving size. They aren't a verified Sri Lankan nutrition reference or a substitute for product labels.

## Notes

- Designed for personal use; not a medical device.
- Offline food search includes the bundled small reference library and foods you create. It is not an online food database.
- No Apple Health integration, camera/barcode scanner, account or cloud sync in version 1.
- A workout's completed sets count toward history and personal records; tap the checkmark after each set.
