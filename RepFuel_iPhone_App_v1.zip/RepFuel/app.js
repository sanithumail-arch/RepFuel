/* RepFuel — completely offline-first fitness logger. No external scripts, APIs or telemetry. */
'use strict';

const $ = selector => document.querySelector(selector);
const esc = text => String(text ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
const dateLabel = date => { const d = new Date(`${date}T12:00:00`); return Number.isNaN(d.getTime()) ? date : d.toLocaleDateString(undefined,{month:'short',day:'numeric',year:'numeric'}); };
const dateShort = date => dateLabel(date).replace(/, \d{4}$/,'');
const fmt = (value,decimals=0) => (Number(value)||0).toLocaleString(undefined,{maximumFractionDigits:decimals});
const uid = () => (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID() : `id-${Date.now()}-${Math.random().toString(36).slice(2)}`;
const clone = obj => JSON.parse(JSON.stringify(obj));
const safeNumber = n => Math.max(0,Math.min(100000,Number(n)||0));
const ico = (name,size=20) => {
  const p = {
    home:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1Z"/>',
    dumbbell:'<path d="m6 7 11 10M4 5l-2 2 4 4 2-2M8 3 6 5l4 4 2-2m4 10-2 2 4 4 2-2m-2-6-2 2 4 4 2-2"/>',
    food:'<path d="M4 3v8a4 4 0 0 0 4 4h1v6M8 3v18M12 3v7M16 3v7M20 3v18a7 7 0 0 1-7-7v-4a7 7 0 0 1 7-7Z"/>',
    chart:'<path d="M4 20V9m6 11V4m6 16v-8m5 8V7"/>',
    plus:'<path d="M12 4v16M4 12h16"/>',
    arrow:'<path d="M4 12h16m-6-6 6 6-6 6"/>',
    check:'<path d="m5 12 4 4L19 6"/>',
    close:'<path d="M5 5 19 19M19 5 5 19"/>',
    trash:'<path d="M4 7h16M10 3h4m-8 4 1 14h10l1-14M10 11v6m4-6v6"/>',
    edit:'<path d="m4 16 0 4h4L20 8l-4-4L4 16Zm9-9 4 4"/>',
    fire:'<path d="M13 3c1 5-3 6-3 10-1-1-2-3-2-4-3 3-3 5-3 7a7 7 0 0 0 14 0c0-4-2-7-6-13Z"/>',
    scale:'<rect x="3" y="5" width="18" height="15" rx="3"/><path d="M9 11a3 3 0 0 1 6 0m-3 0v2"/>',
    trophy:'<path d="M8 21h8m-4-4v4M6 3h12v7a6 6 0 0 1-12 0V3Zm0 2H3v3a4 4 0 0 0 4 4m11-7h3v3a4 4 0 0 1-4 4"/>',
    book:'<path d="M4 4h14a2 2 0 0 1 2 2v14H6a2 2 0 0 1-2-2V4Zm0 13a3 3 0 0 1 3-3h13"/>',
    download:'<path d="M12 3v13m-5-5 5 5 5-5M4 17v4h16v-4"/>',
    upload:'<path d="M12 21V8m-5 5 5-5 5 5M4 7V3h16v4"/>',
    clock:'<circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2"/>',
    lock:'<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
    chevron:'<path d="m9 5 7 7-7 7"/>'
  };
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${p[name]||p.plus}</svg>`;
};
const baseExercises = [
  'Bench Press','Incline Dumbbell Press','Squat','Romanian Deadlift','Deadlift','Leg Press','Lat Pulldown','Seated Cable Row','Overhead Press','Lateral Raise','Bicep Curl','Tricep Pushdown','Leg Curl','Leg Extension','Calf Raise','Pull-up'
].map((name,i)=>({id:`default-ex-${i}`,name}));
// Example reference values per 100 g. They vary with ingredients, preparation and product.
const foodSeeds = [
  ['White rice, cooked',130,2.7,28.2,0.3],['Chicken breast, cooked',165,31,0,3.6],['Whole egg, boiled',155,12.6,1.1,10.6],
  ['Banana',89,1.1,22.8,0.3],['Milk, whole',61,3.2,4.8,3.3],['Oats, dry',389,16.9,66.3,6.9],
  ['Lentils (dhal), boiled',116,9,20.1,0.4],['White bread',265,9,49,3.2],['Chickpeas, boiled',164,8.9,27.4,2.6],
  ['Tuna in water, drained',116,25.5,0,0.8],['Papaya',43,0.5,10.8,0.3],['Potato, boiled',87,1.9,20.1,0.1]
].map(([name,calories,protein,carbs,fat],i)=>({id:`default-food-${i}`,name,calories,protein,carbs,fat,reference:true}));
const initialState = () => ({schema:1,goals:{calories:2000,protein:150,carbs:200,fat:65},goalsPersonalized:false,exercises:clone(baseExercises),routines:[],workouts:[],activeWorkout:null,foods:clone(foodSeeds),meals:[],weighIns:[]});
let state = initialState();
let page = 'home';
let foodDate = today();
let modal = '';
let foodTab = 'library';
let foodSearch = '';
let selectedFoodId = null;
let modalMealType = 'Breakfast';
let toastTimer;
let dbPromise;
let saving = Promise.resolve();

function openDB(){
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve,reject)=>{
    const request = indexedDB.open('repFuelPrivateDb',1);
    request.onupgradeneeded = ()=> request.result.createObjectStore('app');
    request.onsuccess = ()=>resolve(request.result);
    request.onerror = ()=>reject(request.error);
  });
  return dbPromise;
}
async function readStore(){
  const db=await openDB();
  return new Promise((resolve,reject)=>{
    const tx=db.transaction('app','readonly');
    const req=tx.objectStore('app').get('state');
    req.onsuccess=()=>resolve(req.result);
    req.onerror=()=>reject(req.error);
  });
}
async function writeStore(value){
  const db=await openDB();
  return new Promise((resolve,reject)=>{
    const tx=db.transaction('app','readwrite');
    tx.objectStore('app').put(value,'state');
    tx.oncomplete=resolve;
    tx.onerror=()=>reject(tx.error);
  });
}
function persist(){
  const snapshot=clone(state);
  saving=saving.catch(()=>{}).then(()=>writeStore(snapshot)).catch(err=>{console.error('Could not save data',err);toast('Storage unavailable — export a backup');});
  return saving;
}
function toast(message){
  const el=$('#toast');el.textContent=message;el.classList.add('show');
  clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),3100);
}
function setPage(next){page=next;closeModal();render();window.scrollTo({top:0,behavior:'instant'});}
function closeModal(){modal='';$('#modal-root').innerHTML='';}
function navButton(id,label,iconName,desktop=false){
  return `<button class="${desktop?'side-nav-item':'nav-item'} ${page===id?'active':''}" data-action="goto" data-page="${id}" ${page===id?'aria-current="page"':''}>${ico(iconName)}<span>${label}</span></button>`;
}
function renderNav(){
  $('#bottom-nav').innerHTML=navButton('home','Home','home')+navButton('workout','Workout','dumbbell')+navButton('food','Food','food')+navButton('progress','Progress','chart');
  $('#side-nav').innerHTML=navButton('home','Dashboard','home',true)+navButton('workout','Workouts','dumbbell',true)+navButton('food','Food diary','food',true)+navButton('progress','Progress','chart',true);
  $('#date-label').textContent=new Date().toLocaleDateString(undefined,{weekday:'short',month:'short',day:'numeric'});
}
const pageHeading = (eyebrow,title,subtitle,side='') => `<div class="page-heading"><div><div class="eyebrow">${eyebrow}</div><h1>${title}</h1><p class="subtitle">${subtitle}</p></div>${side}</div>`;
function totalsFor(date){
  return state.meals.filter(m=>m.date===date).reduce((a,m)=>({calories:a.calories+m.calories,protein:a.protein+m.protein,carbs:a.carbs+m.carbs,fat:a.fat+m.fat}),{calories:0,protein:0,carbs:0,fat:0});
}
function macroCards(t){
  return `<div class="macro-grid">${[
    ['protein','Protein','#8cbefe'],['carbs','Carbs','#f3c578'],['fat','Fat','#c1a4ec']
  ].map(([key,label,color])=>{
    const v=state.goals[key];const pct=v?Math.min(100,t[key]/v*100):0;
    return `<div class="card macro-card"><div class="macro-top"><i class="macro-dot" style="background:${color}"></i><span class="macro-title">${label}</span></div><div class="macro-values">${fmt(t[key],1)}<span> / ${fmt(v)}g</span></div><div class="bar-track"><div class="bar-fill" style="width:${pct}%;background:${color}"></div></div></div>`;
  }).join('')}</div>`;
}
function caloriesPanel(date){
  const t=totalsFor(date),goal=state.goals.calories,left=Math.round(goal-t.calories),pct=goal?Math.min(100,t.calories/goal*100):0;
  return `<div class="card calorie-card"><div class="calorie-card-inner"><div class="ring" role="img" aria-label="${Math.round(pct)} percent of daily calories consumed" style="--ring-pct:${pct}%"><div class="ring-center"><span class="ring-number">${fmt(Math.abs(left))}</span><span class="ring-label">${left>=0?'kcal left':'kcal over'}</span></div></div><div class="calorie-stats"><div class="tiny-label">DAILY CALORIES</div><div class="big-stat">${fmt(t.calories)}</div><div class="muted-sm">of ${fmt(goal)} kcal goal</div><div class="split-stat"><span>Remaining</span><strong>${left>=0?fmt(left):`-${fmt(-left)}`} kcal</strong></div></div></div></div>${macroCards(t)}`;
}
function mostRecentWorkouts(){return [...state.workouts].sort((a,b)=>b.finishedAt.localeCompare(a.finishedAt));}
function emptyCard(iconName,title,description,action,label){return `<div class="empty-card"><div class="empty-symbol">${ico(iconName,23)}</div><h3>${title}</h3><p>${description}</p>${action?`<button class="btn small outline" data-action="${action}">${label}</button>`:''}</div>`;}
function goalsReminder(){return !state.goalsPersonalized?`<div class="small-note" style="margin:0 0 13px">Daily nutrition goals are examples. <button class="link-button" data-action="settings">Set your own targets ${ico('arrow',13)}</button></div>`:'';}
function renderHome(){
  const recent=mostRecentWorkouts()[0],lastWeight=[...state.weighIns].sort((a,b)=>b.date.localeCompare(a.date))[0];
  return `${pageHeading('TRAIN · FUEL · PROGRESS','Make every rep count.','Your daily snapshot. One step closer to your goals.')}
    ${goalsReminder()}${caloriesPanel(today())}
    <div class="section-heading"><h2>Quick actions</h2></div>
    <div class="action-grid">
      <button class="action-card primary" data-action="quick-workout">${ico('dumbbell',25)}<strong>${state.activeWorkout?'Continue workout':'Start workout'}</strong><small>Log every set and rep</small></button>
      <button class="action-card" data-action="open-food" data-meal="Breakfast">${ico('plus',25)}<strong>Add food</strong><small>Track calories & macros</small></button>
    </div>
    <div class="section-heading"><h2>Your activity</h2><button class="link-button" data-action="goto" data-page="progress">View progress ${ico('arrow',13)}</button></div>
    <div class="card">
      <div class="item-row"><div class="item-info"><div class="tiny-label">LAST WORKOUT</div><div class="item-title" style="margin-top:6px">${recent?esc(recent.title):'No workouts yet'}</div><div class="item-sub">${recent?`${dateLabel(recent.date)} · ${recent.exercises.length} exercises`:'Your first workout will appear here'}</div></div><span class="routine-icon">${ico('dumbbell')}</span></div>
      <div class="item-row"><div class="item-info"><div class="tiny-label">LAST WEIGH-IN</div><div class="item-title" style="margin-top:6px">${lastWeight?`${fmt(lastWeight.kg,2)} kg`:'No weigh-ins yet'}</div><div class="item-sub">${lastWeight?dateLabel(lastWeight.date):'Start recording your body weight'}</div></div><button class="btn small secondary" data-action="open-weigh">${ico('plus',14)} Log</button></div>
    </div>
    <div class="privacy-message">${ico('lock',12)} Private by design. Your records stay on this device.</div>`;
}
function findExercise(id){return state.exercises.find(x=>x.id===id);}
function lastExerciseHistory(id){
  for(const w of mostRecentWorkouts()){
    const match=w.exercises.find(e=>e.exerciseId===id);
    if(match && match.sets.some(s=>s.done))return {date:w.date,sets:match.sets.filter(s=>s.done)};
  }
  return null;
}
function bestWeight(id){
  let best=0;
  for(const w of state.workouts)for(const ex of w.exercises)if(ex.exerciseId===id)for(const s of ex.sets)if(s.done)best=Math.max(best,Number(s.weight)||0);
  return best;
}
function setInputs(ex){
  return `<div class="set-grid head"><span>SET</span><span>KG</span><span>REPS</span><span>DONE</span><span></span></div>${ex.sets.map((s,i)=>`<div class="set-grid"><span class="set-number">${i+1}</span><input aria-label="Weight, set ${i+1}" type="number" min="0" max="99999" step="0.5" inputmode="decimal" class="set-input ${s.done?'done':''}" value="${esc(s.weight??'')}" placeholder="kg" data-set-field="weight" data-xid="${ex.id}" data-sid="${s.id}"/><input aria-label="Reps, set ${i+1}" type="number" min="0" max="9999" step="1" inputmode="numeric" class="set-input ${s.done?'done':''}" value="${esc(s.reps??'')}" placeholder="reps" data-set-field="reps" data-xid="${ex.id}" data-sid="${s.id}"/><button aria-label="Mark set ${i+1} ${s.done?'incomplete':'complete'}" class="done-button ${s.done?'checked':''}" data-action="toggle-set" data-xid="${ex.id}" data-sid="${s.id}">${ico('check',17)}</button><button aria-label="Delete set ${i+1}" class="plain-icon" data-action="delete-set" data-xid="${ex.id}" data-sid="${s.id}">${ico('close',15)}</button></div>`).join('')}`;
}
function renderActiveWorkout(){
  const w=state.activeWorkout;
  return `${pageHeading('LIVE SESSION','Workout in progress','Your progress is saved automatically.')}
    <div class="card workout-banner"><div class="workout-count"><span class="chip">● ACTIVE SESSION</span><span class="muted-sm">Started ${new Date(w.startedAt).toLocaleTimeString(undefined,{hour:'numeric',minute:'2-digit'})}</span></div><h2>${esc(w.title)}</h2><p>${w.exercises.length} exercises · Mark each finished set with ✓</p></div>
    <div class="section-heading"><h2>Exercises</h2><button class="link-button" data-action="add-exercise">${ico('plus',16)} Add exercise</button></div>
    ${w.exercises.length?w.exercises.map(ex=>{
      const meta=findExercise(ex.exerciseId),last=lastExerciseHistory(ex.exerciseId),best=bestWeight(ex.exerciseId);
      const previous=last?last.sets.map(s=>`${fmt(s.weight,1)}×${fmt(s.reps)}`).join(' · '):'First time logging this exercise';
      return `<article class="exercise-card"><div class="exercise-card-header"><div><h3>${esc(meta?.name||'Deleted exercise')}</h3><div class="item-sub">${last?`Last: ${esc(previous)}`:previous}</div>${best>0?`<div class="micro">PR: ${fmt(best,1)} kg</div>`:''}</div><button class="plain-icon" aria-label="Remove exercise" data-action="remove-active-exercise" data-xid="${ex.id}">${ico('trash',18)}</button></div>${setInputs(ex)}<div class="exercise-bottom"><button class="btn small secondary" data-action="add-set" data-xid="${ex.id}">${ico('plus',15)} Add set</button><span class="micro">${ex.sets.filter(s=>s.done).length}/${ex.sets.length} sets finished</span></div></article>`;
    }).join(''):emptyCard('dumbbell','Add your first exercise','Choose an exercise from your library or create your own.','add-exercise','Add exercise')}
    <div class="button-row" style="margin-top:19px"><button class="btn" style="flex:1" data-action="finish-workout">${ico('check',17)} Finish workout</button><button class="btn danger" data-action="discard-workout">Discard</button></div>`;
}
function renderWorkout(){
  if(state.activeWorkout)return renderActiveWorkout();
  return `${pageHeading('STRENGTH JOURNAL','Your workouts.','Track every set. Beat your last session.')}
    <div class="card workout-banner"><span class="chip">READY TO TRAIN</span><h2>What are we training today?</h2><p>Start a blank workout or load one of your saved routines.</p><div class="button-row" style="margin-top:17px"><button class="btn" data-action="start-blank">${ico('plus')} Start empty workout</button></div></div>
    <div class="section-heading"><h2>My routines</h2><button class="link-button" data-action="new-routine">${ico('plus',15)} New routine</button></div>
    ${state.routines.length?state.routines.map(r=>`<div class="routine-row"><span class="routine-icon">${ico('book')}</span><div class="routine-data"><h3>${esc(r.name)}</h3><p>${r.exerciseIds.length} exercises · ${r.exerciseIds.map(id=>findExercise(id)?.name).filter(Boolean).slice(0,2).map(esc).join(', ')}${r.exerciseIds.length>2?'…':''}</p></div><div class="routine-actions"><button class="btn small" data-action="start-routine" data-id="${r.id}">Start</button><button class="plain-icon" aria-label="Edit routine" data-action="edit-routine" data-id="${r.id}">${ico('edit')}</button></div></div>`).join(''):emptyCard('book','No routines saved yet','Create a Push, Pull, Legs or any custom workout template.','new-routine','Create a routine')}
    <div class="section-heading"><h2>Exercise library</h2><button class="link-button" data-action="new-exercise">${ico('plus',15)} Custom exercise</button></div>
    <div class="card"><div class="muted-sm" style="margin-bottom:7px">${state.exercises.length} available exercises. You can add as many of your own as you like.</div>${state.exercises.filter(x=>!x.id.startsWith('default-')).slice(-6).reverse().map(x=>`<div class="item-row"><div class="item-info"><div class="item-title">${esc(x.name)}</div><div class="item-sub">Custom exercise</div></div><span class="tag">kg · reps</span></div>`).join('')||'<p class="micro">Your newly created exercises will appear here.</p>'}</div>`;
}
function renderFood(){
  const t=totalsFor(foodDate);
  const meals=['Breakfast','Lunch','Dinner','Snacks'];
  return `${pageHeading('NUTRITION JOURNAL','Fuel your progress.','A simple way to track what you eat.',`<input class="date-picker" type="date" id="food-date" aria-label="Food diary date" value="${foodDate}"/>`)}
    ${goalsReminder()}${caloriesPanel(foodDate)}
    <div class="section-heading"><h2>Food diary</h2><button class="link-button" data-action="open-food" data-meal="Breakfast">${ico('plus',15)} Add food</button></div>
    ${meals.map(meal=>{
      const entries=state.meals.filter(m=>m.date===foodDate && m.mealType===meal);
      const cal=entries.reduce((a,m)=>a+m.calories,0);
      return `<div class="meal-group"><div class="meal-head"><div><h3>${meal}</h3><span class="micro">${fmt(cal)} kcal</span></div><button class="icon-button" aria-label="Add ${meal}" data-action="open-food" data-meal="${meal}">${ico('plus')}</button></div>${entries.length?entries.map(m=>`<div class="meal-item"><div class="item-info"><strong>${esc(m.name)}</strong><small>${m.grams?`${fmt(m.grams,1)} g · `:''}P ${fmt(m.protein,1)}g · C ${fmt(m.carbs,1)}g · F ${fmt(m.fat,1)}g</small></div><span class="meal-value">${fmt(m.calories)} kcal</span><button class="plain-icon" aria-label="Delete food log" data-action="delete-meal" data-id="${m.id}">${ico('close')}</button></div>`).join(''):'<div class="muted-sm" style="padding-top:11px">Nothing logged yet</div>'}</div>`;
    }).join('')}
    <div class="small-note">Nutrition values in the starter food library are estimates per 100 g. Preparation methods and labels can change actual calories and macros. Use manual entries for precise tracking.</div>`;
}
function lineChart(data){
  if(data.length<2)return `<div class="chart-empty">Log at least 2 weigh-ins to see a trend.</div>`;
  const ordered=[...data].sort((a,b)=>a.date.localeCompare(b.date)).slice(-25);
  const vals=ordered.map(x=>x.kg);
  let lo=Math.min(...vals),hi=Math.max(...vals);const gap=Math.max(0.5,(hi-lo)*.15);lo-=gap;hi+=gap;
  const pts=ordered.map((d,i)=>({x:28+(i/(ordered.length-1))*604,y:161-((d.kg-lo)/(hi-lo))*137}));
  const poly=pts.map(p=>`${p.x},${p.y}`).join(' ');
  return `<svg class="progress-chart" viewBox="0 0 660 190" preserveAspectRatio="none" role="img" aria-label="Body weight over time"><defs><linearGradient id="chartFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#b8f36f" stop-opacity=".22"/><stop offset="1" stop-color="#b8f36f" stop-opacity="0"/></linearGradient></defs><path d="M28 42H632M28 92H632M28 142H632" stroke="#3b4b4b" stroke-width="1" stroke-dasharray="5 8"/><polygon points="28,177 ${poly} 632,177" fill="url(#chartFill)"/><polyline points="${poly}" fill="none" stroke="#b8f36f" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>${pts.map((p,i)=>`<circle cx="${p.x}" cy="${p.y}" r="${i===pts.length-1?5:3}" fill="#b8f36f" stroke="#1c2f23" stroke-width="2"/>`).join('')}<text x="32" y="18" fill="#91a7aa" font-size="12">${fmt(hi,1)} kg</text><text x="32" y="173" fill="#91a7aa" font-size="12">${fmt(lo,1)} kg</text></svg><div class="chart-labels"><span>${dateShort(ordered[0].date)}</span><span>${dateShort(ordered[ordered.length-1].date)}</span></div>`;
}
function personalRecords(){
  const records=new Map();
  state.workouts.forEach(w=>w.exercises.forEach(ex=>ex.sets.filter(s=>s.done && s.weight>0).forEach(s=>{
    const record=records.get(ex.exerciseId);
    if(!record || s.weight>record.weight) records.set(ex.exerciseId,{weight:s.weight,reps:s.reps,date:w.date});
  })));
  return [...records].map(([id,entry])=>({...entry,name:findExercise(id)?.name||'Exercise'})).sort((a,b)=>a.name.localeCompare(b.name));
}
function renderProgress(){
  const mostRecent=[...state.weighIns].sort((a,b)=>b.date.localeCompare(a.date));
  const current=mostRecent[0];
  const previous=mostRecent[1];
  const diff=current&&previous?current.kg-previous.kg:null;
  const records=personalRecords();
  return `${pageHeading('THE LONG GAME','Your progress.','Small improvements add up over time.')}
    <div class="grid-three"><div class="card stat-card"><span class="tiny-label">WORKOUTS</span><div class="num">${state.workouts.length}</div><div class="micro">Completed</div></div><div class="card stat-card"><span class="tiny-label">LATEST WEIGHT</span><div class="num">${current?fmt(current.kg,1):'—'}<span class="unit"> kg</span></div><div class="micro">${diff===null?'No change yet':`${diff>0?'+':''}${fmt(diff,2)} kg vs last`}</div></div><div class="card stat-card"><span class="tiny-label">RECORDS</span><div class="num">${records.length}</div><div class="micro">Exercises with PRs</div></div></div>
    <div class="section-heading"><h2>Body weight trend</h2><button class="link-button" data-action="open-weigh">${ico('plus',15)} Add weigh-in</button></div><div class="card">${lineChart(state.weighIns)}${current?`<div class="micro" style="margin-top:13px">Latest: ${fmt(current.kg,2)} kg on ${dateLabel(current.date)}</div>`:''}</div>
    <div class="section-heading"><h2>Strength records</h2><span class="muted-sm">Heaviest completed set</span></div>
    ${records.length?`<div class="card">${records.map(r=>`<div class="item-row"><div class="item-info"><div class="item-title">${esc(r.name)}</div><div class="item-sub">${dateLabel(r.date)} · ${fmt(r.reps)} reps</div></div><div class="record-badge">${ico('trophy',15)} ${fmt(r.weight,1)} kg</div></div>`).join('')}</div>`:emptyCard('trophy','Your records start here','Mark sets complete during your workouts to track personal bests.')}
    <div class="section-heading"><h2>Workout history</h2></div>
    ${state.workouts.length?`<div class="card">${mostRecentWorkouts().slice(0,25).map(w=>`<div class="item-row"><div class="item-info"><div class="item-title">${esc(w.title)}</div><div class="item-sub">${dateLabel(w.date)} · ${w.exercises.length} exercises</div></div><button class="btn small secondary" data-action="workout-detail" data-id="${w.id}">View ${ico('chevron',13)}</button></div>`).join('')}</div>`:emptyCard('clock','No workout history yet','Complete your first session to see it here.')}
    <div class="section-heading"><h2>Weigh-in history</h2></div>
    ${mostRecent.length?`<div class="card">${mostRecent.slice(0,10).map(w=>`<div class="item-row"><div class="item-info"><div class="item-title">${fmt(w.kg,2)} kg</div><div class="item-sub">${dateLabel(w.date)}</div></div><button class="plain-icon" data-action="delete-weigh" data-id="${w.id}" aria-label="Delete weigh-in">${ico('trash')}</button></div>`).join('')}</div>`:''}`;
}
function render(){renderNav();$('#app-content').innerHTML=page==='workout'?renderWorkout():page==='food'?renderFood():page==='progress'?renderProgress():renderHome();}
function showModal(kind){modal=kind;renderModal();}
function modalFrame(title,content){$('#modal-root').innerHTML=`<div class="modal-scrim" data-overlay="true"><section class="modal" role="dialog" aria-modal="true" aria-label="${esc(title)}"><div class="modal-head"><h2>${esc(title)}</h2><button class="icon-button" data-action="close-modal" aria-label="Close dialog">${ico('close')}</button></div>${content}</section></div>`;}
function renderModal(){
  if(!modal)return;
  if(modal==='settings')return modalFrame('Your settings',`<form id="settings-form"><div class="small-note">Set your own daily nutrition targets. Nothing is sent to a server.</div><div class="field"><label>DAILY CALORIES (KCAL)</label><input type="number" name="calories" min="1" max="10000" required value="${state.goals.calories}"/></div><div class="form-grid"><div class="field"><label>PROTEIN (G)</label><input type="number" name="protein" min="0" max="2000" required value="${state.goals.protein}"/></div><div class="field"><label>CARBS (G)</label><input type="number" name="carbs" min="0" max="2000" required value="${state.goals.carbs}"/></div><div class="field"><label>FAT (G)</label><input type="number" name="fat" min="0" max="2000" required value="${state.goals.fat}"/></div></div><div class="form-actions"><button class="btn full" type="submit">Save goals</button></div></form><div class="separator"></div><h3>Keep your data safe</h3><p class="muted-sm">Your workout and nutrition history stays only in this browser installation. Export backups regularly, especially before switching phones or clearing Safari data.</p><div class="button-row" style="margin-top:13px"><button class="btn secondary" data-action="export-backup">${ico('download')} Export JSON backup</button><button class="btn secondary" data-action="import-backup">${ico('upload')} Import backup</button></div><div class="small-note">Offline food search includes starter nutrition estimates plus foods you add. No account or cloud sync is used.</div>`);
  if(modal==='exercise')return modalFrame('New custom exercise',`<form id="exercise-form"><div class="field"><label>EXERCISE NAME</label><input name="name" placeholder="e.g. Incline chest press" maxlength="90" autocomplete="off" required autofocus/></div><div class="small-note">You can add this exercise to any routine or active workout. Weights are recorded in kg.</div><div class="form-actions"><button class="btn secondary" type="button" data-action="close-modal">Cancel</button><button class="btn" type="submit">Create exercise</button></div></form>`);
  if(modal==='routine'){
    const r=state.routines.find(x=>x.id===routineEditingId);
    return modalFrame(r?'Edit routine':'New workout routine',`<form id="routine-form"><div class="field"><label>ROUTINE NAME</label><input name="name" placeholder="e.g. Push Day" maxlength="90" required value="${esc(r?.name||'')}"/></div><label class="tiny-label">SELECT EXERCISES</label><div class="select-list">${state.exercises.map(e=>`<label class="select-entry"><span><strong>${esc(e.name)}</strong></span><input type="checkbox" name="exercises" value="${e.id}" ${r?.exerciseIds.includes(e.id)?'checked':''}></label>`).join('')}</div><div class="form-actions"><button class="btn secondary" type="button" data-action="close-modal">Cancel</button><button class="btn" type="submit">${r?'Save routine':'Create routine'}</button></div>${r?`<button type="button" class="btn danger full" style="margin-top:10px" data-action="delete-routine" data-id="${r.id}">Delete routine</button>`:''}</form>`);
  }
  if(modal==='add-exercise')return modalFrame('Add exercise to workout',`<input class="search-input" id="exercise-search" placeholder="Search exercises…" autocomplete="off" aria-label="Search exercises"/><div class="select-list" id="exercise-results">${exerciseResults('')}</div><button class="btn secondary full" data-action="new-exercise">${ico('plus')} Create custom exercise</button>`);
  if(modal==='weigh')return modalFrame('Log body weight',`<form id="weigh-form"><div class="form-grid"><div class="field"><label>WEIGHT (KG)</label><input type="number" step="0.01" min="1" max="1000" name="kg" placeholder="e.g. 72.5" required autofocus/></div><div class="field"><label>DATE</label><input type="date" name="date" value="${today()}" required/></div></div><p class="muted-sm">If you already recorded a weight for this date, it will be replaced.</p><div class="form-actions"><button class="btn secondary" type="button" data-action="close-modal">Cancel</button><button class="btn" type="submit">Save weigh-in</button></div></form>`);
  if(modal==='food')return renderFoodModal();
  if(modal==='detail'){
    const w=state.workouts.find(x=>x.id===detailWorkoutId);
    if(!w)return closeModal();
    return modalFrame(w.title,`<p class="muted-sm">${dateLabel(w.date)} · Completed ${new Date(w.finishedAt).toLocaleTimeString(undefined,{hour:'numeric',minute:'2-digit'})}</p>${w.exercises.map(e=>`<div class="card" style="margin-top:10px"><h3>${esc(findExercise(e.exerciseId)?.name||'Exercise')}</h3>${e.sets.filter(s=>s.done).map(s=>`<p class="muted-sm" style="padding:4px 0">${fmt(s.weight,1)} kg × ${fmt(s.reps)} reps</p>`).join('')}</div>`).join('')}<button class="btn danger full" data-action="delete-workout" data-id="${w.id}" style="margin-top:19px">Delete this workout</button>`);
  }
}
let routineEditingId=null;
let detailWorkoutId=null;
function exerciseResults(search){
  const existing=new Set(state.activeWorkout?.exercises.map(e=>e.exerciseId)||[]);
  const matches=state.exercises.filter(e=>e.name.toLowerCase().includes(search.toLowerCase())).slice(0,60);
  return matches.length?matches.map(e=>`<button class="select-entry ${existing.has(e.id)?'selected':''}" type="button" data-action="select-exercise" data-id="${e.id}" ${existing.has(e.id)?'disabled':''}><strong>${esc(e.name)}</strong><span class="select-icon">${existing.has(e.id)?'Added':ico('plus',17)}</span></button>`).join(''):'<div class="no-results">No matches. Try creating a custom exercise.</div>';
}
function foodResults(search){
  const matches=state.foods.filter(f=>f.name.toLowerCase().includes(search.toLowerCase())).slice(0,80);
  return matches.length?matches.map(f=>`<button class="select-entry" type="button" data-action="select-food" data-id="${f.id}"><span><strong>${esc(f.name)}</strong><small>${fmt(f.calories)} kcal · P ${fmt(f.protein,1)}g · C ${fmt(f.carbs,1)}g · F ${fmt(f.fat,1)}g / 100g${f.reference?' · estimate':''}</small></span>${ico('chevron',15)}</button>`).join(''):'<div class="no-results">No foods found. Add your own with the Custom food tab.</div>';
}
function renderFoodModal(){
  const mealSelect=`<div class="field"><label>MEAL</label><select name="mealType">${['Breakfast','Lunch','Dinner','Snacks'].map(m=>`<option ${modalMealType===m?'selected':''}>${m}</option>`).join('')}</select></div>`;
  const tabs=`<div class="tabs"><button class="tab ${foodTab==='library'?'active':''}" data-action="food-tab" data-tab="library">Search foods</button><button class="tab ${foodTab==='manual'?'active':''}" data-action="food-tab" data-tab="manual">Manual entry</button><button class="tab ${foodTab==='custom'?'active':''}" data-action="food-tab" data-tab="custom">Custom food</button></div>`;
  let content='';
  if(foodTab==='library'){
    const f=state.foods.find(x=>x.id===selectedFoodId);
    content=f?`<button class="link-button" data-action="food-back">← Back to search</button><h3>${esc(f.name)}</h3><p class="muted-sm">${fmt(f.calories)} kcal per 100 g ${f.reference?'(estimate)':''}</p><form id="food-library-form"><div class="field"><label>AMOUNT EATEN (GRAMS)</label><input name="grams" type="number" min="1" max="10000" step="1" value="100" required/></div>${mealSelect}<div class="form-actions"><button type="submit" class="btn full">Add to diary</button></div></form>`:`<div class="field"><label>SEARCH LOCAL FOOD LIBRARY</label><input class="search-input" id="food-search" placeholder="Rice, chicken, banana…" value="${esc(foodSearch)}" autocomplete="off" /></div><div class="select-list" id="food-results">${foodResults(foodSearch)}</div><p class="micro">Food search works without internet. Included food values are reference estimates.</p>`;
  } else if(foodTab==='manual'){
    content=`<form id="food-manual-form"><div class="field"><label>FOOD OR MEAL NAME</label><input name="name" maxlength="110" placeholder="e.g. Lunch rice and curry" required /></div>${mealSelect}<div class="form-grid"><div class="field"><label>CALORIES (KCAL)</label><input name="calories" type="number" min="0" max="10000" step="0.1" required placeholder="450" /></div><div class="field"><label>PROTEIN (G)</label><input name="protein" type="number" min="0" max="2000" step="0.1" required placeholder="25" /></div><div class="field"><label>CARBS (G)</label><input name="carbs" type="number" min="0" max="2000" step="0.1" required placeholder="55" /></div><div class="field"><label>FAT (G)</label><input name="fat" type="number" min="0" max="2000" step="0.1" required placeholder="10" /></div></div><p class="muted-sm">Enter totals for the portion you actually ate.</p><div class="form-actions"><button type="submit" class="btn full">Add meal to diary</button></div></form>`;
  } else {
    content=`<form id="custom-food-form"><div class="field"><label>FOOD NAME</label><input name="name" maxlength="110" placeholder="e.g. Homemade chicken curry" required/></div><p class="muted-sm">Enter nutrition per 100 g. This saves your food to the searchable offline library.</p><div class="form-grid"><div class="field"><label>CALORIES (KCAL)</label><input name="calories" type="number" min="0" max="10000" step="0.1" required/></div><div class="field"><label>PROTEIN (G)</label><input name="protein" type="number" min="0" max="2000" step="0.1" required/></div><div class="field"><label>CARBS (G)</label><input name="carbs" type="number" min="0" max="2000" step="0.1" required/></div><div class="field"><label>FAT (G)</label><input name="fat" type="number" min="0" max="2000" step="0.1" required/></div></div><div class="form-actions"><button type="submit" class="btn full">Save custom food</button></div></form>`;
  }
  return modalFrame('Log your food',tabs+content);
}
function newSet(previous){return {id:uid(),weight:previous?.weight??'',reps:previous?.reps??'',done:false};}
function workoutExercise(exerciseId){
  const history=lastExerciseHistory(exerciseId),prev=history?.sets?.[0];
  return {id:uid(),exerciseId,sets:[newSet(prev)]};
}
function startWorkout(routine){
  if(state.activeWorkout)return setPage('workout');
  state.activeWorkout={id:uid(),title:routine?.name||'Free Workout',date:today(),startedAt:new Date().toISOString(),routineId:routine?.id||null,exercises:(routine?.exerciseIds||[]).map(workoutExercise)};
  persist();setPage('workout');toast('Workout started');
}
function addSet(xid){const ex=state.activeWorkout?.exercises.find(e=>e.id===xid);if(!ex)return;ex.sets.push(newSet(ex.sets[ex.sets.length-1]));persist();render();}
function activateFood(meal){modalMealType=meal||'Breakfast';foodTab='library';foodSearch='';selectedFoodId=null;showModal('food');}
function addMeal(m){state.meals.push({id:uid(),date:foodDate,...m});persist();closeModal();render();toast('Added to your food diary');}
function submitForm(event){
  const form=event.target;
  if(!form.id)return;
  event.preventDefault();
  const d=Object.fromEntries(new FormData(form).entries());
  if(form.id==='settings-form'){
    const c=safeNumber(d.calories);if(c<1)return toast('Enter a calorie target greater than zero');
    state.goals={calories:c,protein:safeNumber(d.protein),carbs:safeNumber(d.carbs),fat:safeNumber(d.fat)};state.goalsPersonalized=true;persist();closeModal();render();toast('Daily goals updated');
  } else if(form.id==='exercise-form'){
    const name=d.name.trim();if(!name)return;
    if(state.exercises.some(e=>e.name.toLowerCase()===name.toLowerCase()))return toast('This exercise already exists');
    const e={id:uid(),name};state.exercises.push(e);
    if(state.activeWorkout)state.activeWorkout.exercises.push(workoutExercise(e.id));
    persist();closeModal();render();toast('Exercise created');
  } else if(form.id==='routine-form'){
    const name=d.name.trim();const exerciseIds=[...form.querySelectorAll('input[name="exercises"]:checked')].map(e=>e.value);
    if(!name)return;
    if(!exerciseIds.length)return toast('Select at least one exercise');
    const existing=state.routines.find(r=>r.id===routineEditingId);
    if(existing){existing.name=name;existing.exerciseIds=exerciseIds;}else state.routines.push({id:uid(),name,exerciseIds});
    routineEditingId=null;persist();closeModal();render();toast('Routine saved');
  } else if(form.id==='weigh-form'){
    const kg=Number(d.kg);if(!Number.isFinite(kg)||kg<1||kg>1000)return toast('Enter a valid weight');
    const w=state.weighIns.find(x=>x.date===d.date);
    if(w)w.kg=kg;else state.weighIns.push({id:uid(),date:d.date,kg});
    persist();closeModal();render();toast('Weight recorded');
  } else if(form.id==='food-library-form'){
    const f=state.foods.find(x=>x.id===selectedFoodId),g=Number(d.grams);
    if(!f||!Number.isFinite(g)||g<=0||g>10000)return toast('Enter a valid amount');
    const r=g/100;
    addMeal({name:f.name,grams:g,mealType:d.mealType,calories:f.calories*r,protein:f.protein*r,carbs:f.carbs*r,fat:f.fat*r});
  } else if(form.id==='food-manual-form'){
    const name=d.name.trim();if(!name)return;
    addMeal({name,grams:null,mealType:d.mealType,calories:safeNumber(d.calories),protein:safeNumber(d.protein),carbs:safeNumber(d.carbs),fat:safeNumber(d.fat)});
  } else if(form.id==='custom-food-form'){
    const name=d.name.trim();if(!name)return;
    const f={id:uid(),name,calories:safeNumber(d.calories),protein:safeNumber(d.protein),carbs:safeNumber(d.carbs),fat:safeNumber(d.fat),reference:false};
    state.foods.push(f);persist();selectedFoodId=f.id;foodTab='library';foodSearch='';renderFoodModal();toast('Custom food saved to library');
  }
}
function confirmAction(message){return window.confirm(message);}
function handleAction(el){
  const action=el.dataset.action,id=el.dataset.id,xid=el.dataset.xid,sid=el.dataset.sid;
  if(action==='goto')return setPage(el.dataset.page);
  if(action==='settings')return showModal('settings');
  if(action==='close-modal')return closeModal();
  if(action==='quick-workout')return state.activeWorkout?setPage('workout'):startWorkout();
  if(action==='start-blank')return startWorkout();
  if(action==='start-routine')return startWorkout(state.routines.find(r=>r.id===id));
  if(action==='new-exercise')return showModal('exercise');
  if(action==='new-routine'){routineEditingId=null;return showModal('routine');}
  if(action==='edit-routine'){routineEditingId=id;return showModal('routine');}
  if(action==='delete-routine'){
    if(!confirmAction('Delete this routine? Your completed workout history will stay intact.'))return;
    state.routines=state.routines.filter(r=>r.id!==id);persist();closeModal();render();return toast('Routine deleted');
  }
  if(action==='add-exercise')return showModal('add-exercise');
  if(action==='select-exercise'){
    if(!state.activeWorkout)return;
    if(state.activeWorkout.exercises.some(e=>e.exerciseId===id))return;
    state.activeWorkout.exercises.push(workoutExercise(id));persist();closeModal();render();return toast('Exercise added');
  }
  if(action==='add-set')return addSet(xid);
  if(action==='delete-set'){
    const ex=state.activeWorkout?.exercises.find(e=>e.id===xid);if(!ex)return;
    ex.sets=ex.sets.filter(s=>s.id!==sid);persist();return render();
  }
  if(action==='toggle-set'){
    const ex=state.activeWorkout?.exercises.find(e=>e.id===xid),s=ex?.sets.find(x=>x.id===sid);if(!s)return;
    if(!s.done && (!Number.isFinite(Number(s.weight))||Number(s.weight)<0||Number(s.reps)<=0))return toast('Enter weight and reps first');
    s.done=!s.done;persist();render();return;
  }
  if(action==='remove-active-exercise'){
    if(!confirmAction('Remove this exercise and its sets from the active workout?'))return;
    state.activeWorkout.exercises=state.activeWorkout.exercises.filter(e=>e.id!==xid);persist();return render();
  }
  if(action==='finish-workout'){
    const w=state.activeWorkout;if(!w)return;
    const exercises=w.exercises.map(ex=>({...ex,sets:ex.sets.filter(s=>s.done)})).filter(ex=>ex.sets.length);
    if(!exercises.length)return toast('Complete at least one set before finishing');
    state.workouts.push({...w,exercises,finishedAt:new Date().toISOString()});state.activeWorkout=null;
    persist();setPage('progress');return toast('Workout saved! Great work.');
  }
  if(action==='discard-workout'){
    if(!confirmAction('Discard this workout? This cannot be undone.'))return;
    state.activeWorkout=null;persist();render();return toast('Workout discarded');
  }
  if(action==='open-food')return activateFood(el.dataset.meal);
  if(action==='food-tab'){foodTab=el.dataset.tab;selectedFoodId=null;return renderFoodModal();}
  if(action==='select-food'){selectedFoodId=id;return renderFoodModal();}
  if(action==='food-back'){selectedFoodId=null;return renderFoodModal();}
  if(action==='delete-meal'){
    if(!confirmAction('Remove this food entry?'))return;
    state.meals=state.meals.filter(x=>x.id!==id);persist();return render();
  }
  if(action==='open-weigh')return showModal('weigh');
  if(action==='delete-weigh'){
    if(!confirmAction('Delete this weigh-in?'))return;
    state.weighIns=state.weighIns.filter(x=>x.id!==id);persist();return render();
  }
  if(action==='workout-detail'){detailWorkoutId=id;return showModal('detail');}
  if(action==='delete-workout'){
    if(!confirmAction('Delete this workout permanently?'))return;
    state.workouts=state.workouts.filter(x=>x.id!==id);persist();closeModal();render();return toast('Workout deleted');
  }
  if(action==='export-backup')return exportBackup();
  if(action==='import-backup')return $('#backup-upload').click();
}
function exportBackup(){
  const backup={app:'RepFuel',schema:1,exportedAt:new Date().toISOString(),data:state};
  const blob=new Blob([JSON.stringify(backup,null,2)],{type:'application/json'});
  const link=document.createElement('a');const url=URL.createObjectURL(blob);
  link.href=url;link.download=`repFuel-backup-${today()}.json`;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);toast('Backup ready — save it in Files');
}
function validateImport(raw){
  if(!raw||raw.app!=='RepFuel'||raw.schema!==1||!raw.data)throw Error('Not a compatible RepFuel backup');
  const d=raw.data;
  if(!d.goals||!Array.isArray(d.exercises)||!Array.isArray(d.routines)||!Array.isArray(d.workouts)||!Array.isArray(d.foods)||!Array.isArray(d.meals)||!Array.isArray(d.weighIns))throw Error('Backup is missing required data');
  if(d.exercises.length>5000||d.meals.length>100000||d.workouts.length>20000)throw Error('Backup is too large');
  // Only load known storage fields, and re-validate numeric goal values.
  return {schema:1,goals:{calories:Math.max(1,safeNumber(d.goals.calories)),protein:safeNumber(d.goals.protein),carbs:safeNumber(d.goals.carbs),fat:safeNumber(d.goals.fat)},goalsPersonalized:Boolean(d.goalsPersonalized),exercises:d.exercises,routines:d.routines,workouts:d.workouts,activeWorkout:d.activeWorkout||null,foods:d.foods,meals:d.meals,weighIns:d.weighIns};
}
async function importBackup(file){
  if(!file)return;
  try{
    if(file.size>20*1024*1024)throw Error('Maximum backup file size is 20 MB');
    const parsed=JSON.parse(await file.text());const imported=validateImport(parsed);
    if(!confirmAction('Import this backup? It will REPLACE all current workout, food and weight data on this device.'))return;
    state=imported;await persist();closeModal();page='home';render();toast('Backup imported successfully');
  }catch(err){toast(err.message||'Unable to import backup');}
}

document.addEventListener('click',event=>{
  const control=event.target.closest('[data-action]');
  if(control){event.preventDefault();return handleAction(control);}
  if(event.target.matches('.modal-scrim'))closeModal();
});
document.addEventListener('submit',submitForm);
document.addEventListener('change',event=>{
  const t=event.target;
  if(t.id==='food-date'){if(/^\d{4}-\d{2}-\d{2}$/.test(t.value)){foodDate=t.value;render();}return;}
  if(t.dataset.setField){
    const ex=state.activeWorkout?.exercises.find(e=>e.id===t.dataset.xid),s=ex?.sets.find(s=>s.id===t.dataset.sid);
    if(!s)return;
    if(t.value==='')s[t.dataset.setField]='';else s[t.dataset.setField]=safeNumber(t.value);
    if(s.done)s.done=false;
    persist();
  }
});
document.addEventListener('input',event=>{
  if(event.target.id==='food-search'){
    foodSearch=event.target.value;const list=$('#food-results');if(list)list.innerHTML=foodResults(foodSearch);
  }
  if(event.target.id==='exercise-search'){
    const list=$('#exercise-results');if(list)list.innerHTML=exerciseResults(event.target.value);
  }
});
document.addEventListener('keydown',event=>{if(event.key==='Escape')closeModal();});
$('#backup-upload').addEventListener('change',async e=>{await importBackup(e.target.files[0]);e.target.value='';});

(async function init(){
  try{
    const saved=await readStore();
    if(saved)state={...initialState(),...saved};
    else await persist();
  }catch(err){
    console.error('IndexedDB not available',err);
    $('#app-content').innerHTML='<div class="empty-card" style="margin-top:60px"><h3>Local storage is unavailable</h3><p>RepFuel needs browser storage to keep your workouts and food logs. Enable website data in Safari, then reload.</p></div>';
    return;
  }
  render();
  if('serviceWorker' in navigator && (location.protocol==='https:' || location.hostname==='localhost')){
    navigator.serviceWorker.register('./sw.js').catch(err=>console.warn('Offline setup unavailable',err));
  }
})();
